<?php

//PARAMETRE A MODIFIER

$module_connection=1 ; // permet de désactivé les fonctionalités de connexion mettre à 0 pour désactivé (cas ldap par exemple)

$bdd_name='dolibarr'; //nom de la base de donnée dolibarr
$domaine='localhost';// adresse du serveur de base de donnée
$port='3306' ; //port du serveur de base de donnée
$bdd_utilisateur='root'; //nom de l'utilisateur de la base de donnee dolibarr
$bdd_password='root'; // mot de passe de la base


// FIN DES PARAMETREs A MODIFIER

?>

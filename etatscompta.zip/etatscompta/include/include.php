<?php
session_start();
include('conf.inc.php');
include('connection.php');
include('fonction_gen.php') ;
include('fonction_compte.php') ;
include('fonction_compte_aux.php') ;
include('fonction_ana.php') ;
include('menu.php');  
?>

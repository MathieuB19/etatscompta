<?php 
//en tete du fichier 
?>

<!DOCTYPE html>
<html>
  <head>
    <title><?php echo $titre_du_site ; ?></title>
 <link type="text/css" href="include/style.css"    rel="stylesheet" />

  </head>
  <body> 



  
<?php


// affichage du menu

?>

<p class='menu'>
<table border=2 align=center><tr align=center><td>
<a href="index.php">Accueil </a>
</td><td>
<a href="exercices.php">Configuration </a>
</td><td>
<a href="grandlivre.php">Grand Livre </a>
</td><td>
<a href="balance.php">Balance </a>
</td><td>
<a href="cr.php">Compte de résultat </a>
</td>
<td>
<a href="crana.php">Compte de résultat ANA</a>
</td>
</tr>
<tr align=center>
<td>
<a href="bilan.php">Bilan </a>
</td>
<td>
<a href="bilanana.php">Bilan ANA </a>
</td>
<td>
<a href="rapportcompte.php">Rapport compte</a>
</td>
<td>
<a href="gencloture.php">Générer Cloture</a>
</td>
<td>
<a href="verifcloture.php">Verifier Cloture</a>
</td>
<td>
<a href="deco.php">Déconnexion</a>
</td>
</tr></table>
</p>


